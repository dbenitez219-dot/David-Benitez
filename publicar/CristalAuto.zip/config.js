/* Conexión a Supabase. La clave "publishable" es pública por diseño: la seguridad la da el inicio de sesión y las reglas (RLS) de la base. */
window.SB_CONFIG = {
  url: 'https://nmvlnyxgfhveleeewklg.supabase.co',
  key: 'sb_publishable_malo3Q2XwfqBH1GCGOc9uw_XIWStLQa',
  fn: 'CRISTALAUTO', // nombre exacto de la función de avisos en Supabase (importan las mayúsculas)
  fnAsistente: 'asistente', // función del asistente (en minúsculas)
};
